import React from "react";
import "./style.css";

export const Box = () => {
  return (
    <div className="box">
      <div className="landing-page-wrapper">
        <div className="landing-page">
          <div className="overlap">
            <div className="rectangle" />
            <div className="group">
              <div className="overlap-group">
                <div className="text-wrapper">voir plus</div>
              </div>
            </div>
            <div className="div">Découvrez vos services</div>
            <img className="polygon" alt="Polygon" src="/img/polygon-1.svg" />
            <div className="group-2">
              <div className="overlap-group-wrapper">
                <div className="overlap-group-2">
                  <div className="rectangle-2" />
                  <img className="hands-box" alt="Hands box" src="/img/hands-box.png" />
                  <div className="text-wrapper-2">Ramassage à domicile</div>
                  <p className="le-ramassage-des">
                    Le ramassage des colis s&#39;effectuer selon votre choix et depuis vos locaux souhaité.
                  </p>
                </div>
              </div>
              <div className="overlap-wrapper">
                <div className="overlap-group-2">
                  <div className="rectangle-2" />
                  <img className="hands-checkmark" alt="Hands checkmark" src="/img/hands-checkmark.png" />
                  <div className="text-wrapper-3">Livraison à domicile</div>
                  <p className="flypak-vous-permet-d">
                    Flypak vous permet d&#39;expédier vos colis rapidement et en toute tranquillité.
                  </p>
                </div>
              </div>
              <div className="div-wrapper">
                <div className="overlap-group-2">
                  <div className="rectangle-2" />
                  <img className="hands-calendar" alt="Hands calendar" src="/img/hands-calendar.png" />
                  <div className="text-wrapper-4">Suivre en temps réel</div>
                  <p className="p">
                    Nous offrons une plateforme efficace pour la gestion et le suivi de tous vos colis expédié.
                  </p>
                </div>
              </div>
            </div>
          </div>
          <div className="overlap-2">
            <img className="gettyimages" alt="Gettyimages" src="/img/gettyimages-1289874631-612x612-1.png" />
            <div className="group-3">
              <div className="overlap-group">
                <div className="text-wrapper">voir plus</div>
              </div>
            </div>
            <div className="group-4">
              <div className="text-wrapper-5">Solution de Livraison E-commerce</div>
              <div className="text" />
            </div>
          </div>
          <div className="barre-menu">
            <div className="navbar">
              <div className="text-wrapper-6">Acceuil</div>
              <div className="text-wrapper-6">Nos services</div>
              <div className="text-wrapper-6">Tarifs</div>
              <div className="text-wrapper-6">Mon espace</div>
            </div>
            <div className="group-5">
              <div className="overlap-group-3">
                <div className="text-wrapper">s’inscrire</div>
              </div>
            </div>
            <img className="img" alt="Group" src="/img/group-20.png" />
          </div>
          <div className="overlap-3">
            <div className="group-6">
              <div className="overlap-4">
                <div className="text-wrapper-7">contactez-nous</div>
              </div>
            </div>
            <div className="overlap-5">
              <div className="group-wrapper">
                <div className="group-7">
                  <div className="overlap-group-4">
                    <img className="mapmaroc" alt="Mapmaroc" src="/img/mapmaroc-1.png" />
                    <div className="text-wrapper-8">agadir</div>
                    <div className="text-wrapper-9">casa</div>
                    <div className="text-wrapper-10">kesh</div>
                    <div className="text-wrapper-11">tanger</div>
                    <div className="text-wrapper-12">dakhla</div>
                    <div className="text-wrapper-13">rabat</div>
                    <img className="beep-beep-location" alt="Beep beep location" src="/img/beep-beep-location-10.png" />
                    <img
                      className="beep-beep-location-2"
                      alt="Beep beep location"
                      src="/img/beep-beep-location-2.png"
                    />
                    <img
                      className="beep-beep-location-3"
                      alt="Beep beep location"
                      src="/img/beep-beep-location-6.png"
                    />
                    <img
                      className="beep-beep-location-4"
                      alt="Beep beep location"
                      src="/img/beep-beep-location-2.png"
                    />
                    <img
                      className="beep-beep-location-5"
                      alt="Beep beep location"
                      src="/img/beep-beep-location-2.png"
                    />
                    <img className="beep-beep-location-6" alt="Beep beep location" src="/img/beep-beep-location.png" />
                  </div>
                </div>
              </div>
              <p className="text-wrapper-14">
                Nos agences occupent les grandes villes du Maroc, pour faciliter et accélérer la livraison entre les
                villes.
              </p>
            </div>
          </div>
          <div className="overlap-6">
            <img className="vector" alt="Vector" src="/img/vector-6.svg" />
            <img className="gettyimages-2" alt="Gettyimages" src="/img/gettyimages-1053089756-612x612-1.png" />
          </div>
          <div className="overlap-7">
            <div className="rectangle-3" />
            <div className="text-wrapper-15">Nos agences</div>
            <img className="hands-phone" alt="Hands phone" src="/img/hands-phone.png" />
          </div>
          <p className="text-wrapper-16">Une solution adaptée à tous vos besoins.</p>
          <div className="text-wrapper-17">A propos</div>
          <p className="flypak-est-une-soci">
            Flypak est une société qui a crée&nbsp;&nbsp;plusieurs agence au différente ville, la premiére agence est en
            cœur de Casablanca.
            <br />
            <br />
            Notre société dispose de plusieurs compétences dédiées à la satisfaction de nos clients.
          </p>
          <div className="group-8">
            <div className="text-wrapper-18">colis livré</div>
            <div className="element">
              <span className="span">+</span>
              <span className="text-wrapper-19"> 999</span>
            </div>
          </div>
          <div className="group-9">
            <div className="text-wrapper-18">client satisfait</div>
            <div className="element-2">
              <span className="span">%</span>
              <span className="text-wrapper-19"> 87</span>
            </div>
          </div>
          <div className="frame">
            <div className="group-10">
              <div className="group-11">
                <div className="group-12">
                  <div className="overlap-group-5">
                    <div className="text-wrapper-20">livraison e-commerce</div>
                    <h1 className="h-1">flypak</h1>
                    <img className="vector-2" alt="Vector" src="/img/vector-4.svg" />
                    <img className="vector-3" alt="Vector" src="/img/vector-2.svg" />
                    <img className="vector-4" alt="Vector" src="/img/vector.svg" />
                  </div>
                </div>
                <p className="text-wrapper-21">
                  Flypak offre une meilleur solution de la livraison e-commerce au Maroc, transfert et ramassage des
                  colis en toute sécurité.
                </p>
                <p className="lun-ven">
                  Lun – Ven : 09:00 – 17:00
                  <br />
                  Sam : 09:00 – 13:00
                </p>
                <div className="text-wrapper-22">Horaires de travail</div>
                <div className="text-wrapper-23">Liens importants</div>
                <div className="frame-2">
                  <div className="text-wrapper-24">mon espace</div>
                  <div className="text-wrapper-25">nos services</div>
                  <div className="text-wrapper-25">tarifs</div>
                  <div className="text-wrapper-25">FAQ</div>
                </div>
                <div className="text-wrapper-26">Contactez-nous</div>
                <p className="commercial">
                  <span className="text-wrapper-27">Commercial :</span>
                  <span className="text-wrapper-28">
                    {" "}
                    +2126------ 81
                    <br />
                  </span>
                  <span className="text-wrapper-27">Support : </span>
                  <span className="text-wrapper-28">
                    +2126 ------ 61
                    <br />
                  </span>
                  <span className="text-wrapper-27">Email </span>
                  <span className="text-wrapper-28">: </span>
                  <a href="mailto:contact@diacolis.ma" rel="noopener noreferrer" target="_blank">
                    <span className="text-wrapper-29">
                      contact@flypak.ma
                      <br />
                    </span>
                  </a>
                </p>
                <img className="line" alt="Line" src="/img/line-1.svg" />
                <p className="copyright">
                  <span className="text-wrapper-28">Copyright © 2020 Flypak, </span>
                  <span className="text-wrapper-27">Tous les droits sont réservés.</span>
                </p>
                <div className="group-13">
                  <div className="overlap-8">
                    <div className="text-wrapper-7">contactez-nous</div>
                  </div>
                </div>
                <p className="nous-aimerions-vous">Nous aimerions vous écouter, N&#39;hésitez pas de nous contacter</p>
                <img className="group-14" alt="Group" src="/img/group-23.png" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
